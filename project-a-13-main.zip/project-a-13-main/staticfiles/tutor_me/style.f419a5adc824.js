// In your Javascript (external .js resource or <script> tag)
